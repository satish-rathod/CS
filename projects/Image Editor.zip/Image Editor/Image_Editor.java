import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;

class Image_Editor 
{
    public JFrame frame;
    public JLabel imageLabel;
    public BufferedImage originalImage;
    public BufferedImage editedImage;
    Image_Editor()
    {
        // create frame
        frame = new JFrame("Image Editor");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // create image label
        imageLabel = new JLabel();
        frame.add(imageLabel);
        frame.setVisible(true);
        frame.add(imageLabel, BorderLayout.CENTER);

        // create menu bar
        JMenuBar menuBar = new JMenuBar();
        
        // create menu
        JMenu fileMenu = new JMenu("File");
        
        JMenuItem openItem = new JMenuItem("Open");
        openItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // call open image function
                openImage();
            }
        });
        fileMenu.add(openItem);
        JMenuItem saveItem = new JMenuItem("Save");
        saveItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // call save image function
                saveImage();
            }
        });
        fileMenu.add(saveItem);


        JMenu editMenu = new JMenu("Edit");

        // brigthness with slider

        JMenuItem brightnessItem = new JMenuItem("Brightness");
        brightnessItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Create a new JFrame for the brightness adjustment UI
                JFrame brightnessFrame = new JFrame("Brightness Adjustment");
                brightnessFrame.setSize(200, 150);
                brightnessFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
                // Create slider
                JSlider slider = new JSlider(-100, 100, 0);
                slider.setMajorTickSpacing(30);
                slider.setMinorTickSpacing(10);
                slider.setPaintTicks(true);
                slider.setPaintLabels(true);
                
                // Create OK button
                JButton okButton = new JButton("OK");
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        int val = slider.getValue();
                        brightness(val);
                        brightnessFrame.dispose(); // Close the brightness adjustment dialog
                    }
                });
        
                // Create Cancel button
                JButton cancelButton = new JButton("Cancel");
                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        brightness(0);
                        brightnessFrame.dispose(); // Close the brightness adjustment dialog
                    }
                });
        
                // Create slider panel
                JPanel sliderPanel = new JPanel();
                sliderPanel.add(slider);
        
                // Create button panel
                JPanel buttonPanel = new JPanel();
                buttonPanel.add(okButton);
                buttonPanel.add(cancelButton);
        
                // Create main panel for the brightness adjustment UI
                JPanel mainPanel = new JPanel();
                mainPanel.setLayout(new BorderLayout());
                mainPanel.add(sliderPanel, BorderLayout.CENTER);
                mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
                // Add the main panel to the brightnessFrame
                brightnessFrame.add(mainPanel);
        
                // Set the brightnessFrame visible
                brightnessFrame.setVisible(true);
            }
        });
        editMenu.add(brightnessItem);

        // contrast with slider
        JMenuItem contrastItem = new JMenuItem("Contrast");
contrastItem.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        // Create a new JFrame for the contrast adjustment UI
        JFrame contrastFrame = new JFrame("Contrast Adjustment");
        contrastFrame.setSize(300, 150);
        contrastFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create slider
        JSlider slider = new JSlider(50, 200, 100);
        slider.setMajorTickSpacing(25);
        slider.setMinorTickSpacing(10);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);

        // Create OK button
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double factor = slider.getValue() / 100.0; // Convert to a factor between 0.5 and 2.0
                contrast(factor);
                contrastFrame.dispose(); // Close the contrast adjustment dialog
            }
        });

        // Create Cancel button
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                contrast(1.0); // Reset contrast to default (no change)
                contrastFrame.dispose(); // Close the contrast adjustment dialog
            }
        });

        // Create slider panel
        JPanel sliderPanel = new JPanel();
        sliderPanel.add(slider);

        // Create button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);

        // Create main panel for the contrast adjustment UI
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(sliderPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add the main panel to the contrastFrame
        contrastFrame.add(mainPanel);

        // Set the contrastFrame visible
        contrastFrame.setVisible(true);
    }
});
editMenu.add(contrastItem);
        

        // invert
        JMenu invertItem = new JMenu("Invert");
        JMenuItem invertVerticalItem = new JMenuItem("Invert Vertically");
        invertVerticalItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // call invert function
                inversion(1);
            }
        });
        invertItem.add(invertVerticalItem);
        JMenuItem invertHorizontalItem = new JMenuItem("Invert Horizontally");
        invertHorizontalItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // call invert function
                inversion(2);
            }
        });
        invertItem.add(invertHorizontalItem);
        editMenu.add(invertItem);

      

        // rotate
        JMenu rotateItem = new JMenu("Rotate");
JMenuItem rotate90Item = new JMenuItem("Rotate 90°");
rotate90Item.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        rotateImage(90);
    }
});
rotateItem.add(rotate90Item);

JMenuItem rotate180Item = new JMenuItem("Rotate 180°");
rotate180Item.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        rotateImage2(180);
    }
});
rotateItem.add(rotate180Item);

JMenuItem rotate270Item = new JMenuItem("Rotate 270°");
rotate270Item.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        rotateImage(270);
    }
});
rotateItem.add(rotate270Item);

 JMenu effectsMenu = new JMenu("Effects");

    // Grayscale filter
    JMenuItem grayscaleItem = new JMenuItem("Grayscale");
    grayscaleItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            applyGrayscale();
        }
    });
    effectsMenu.add(grayscaleItem);

    JMenuItem negativeImageItem = new JMenuItem("Negative Image");

    negativeImageItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            applyNegativeEffect();
        }
    });
    effectsMenu.add(negativeImageItem);


    // Blur filter
    JMenu blurMenu = new JMenu("Blur");
    JSlider blurRadiusSlider = new JSlider(3, 10, 3); // Define the blur radius slider with a range of 1-10
    JLabel blurRadiusLabel = new JLabel("Blur Radius: 1");

    blurRadiusSlider.addChangeListener(new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
            int radius = blurRadiusSlider.getValue();
            blurRadiusLabel.setText("Blur Radius: " + radius);
        }
    });

    // Add the slider to the "Blur" menu
    blurMenu.add(blurRadiusSlider);

    // Add OK and Cancel buttons for blur
    JMenuItem applyBlurItem = new JMenuItem("Apply Blur");
    JMenuItem cancelBlurItem = new JMenuItem("Cancel Blur");

    applyBlurItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            int radius = blurRadiusSlider.getValue();
            applyBlur(radius);
        }
    });

    cancelBlurItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            blurRadiusSlider.setValue(1); // Reset the slider value to 1
            blurRadiusLabel.setText("Blur Radius: 1");
        }
    });

    blurMenu.add(applyBlurItem);
    blurMenu.add(cancelBlurItem);
    effectsMenu.add(blurMenu);

    // Fade filter
    JMenuItem fadeItem = new JMenuItem("Fade");
    fadeItem.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            applyFade();
        }
    });
    effectsMenu.add(fadeItem);

    // Add the "Effects" menu to the "Edit" menu
    editMenu.add(effectsMenu);

editMenu.add(rotateItem);

        //make bar visible 
        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        frame.setJMenuBar(menuBar);
        frame.setVisible(true);
        }

    // open image
    public void openImage()
    {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.home"))); 
        int result = fileChooser.showOpenDialog(frame);
        if (result == JFileChooser.APPROVE_OPTION) 
        {
            try
            {
                File selectedFile = fileChooser.getSelectedFile();
                originalImage = ImageIO.read(selectedFile);
                editedImage = originalImage;
                displayImage();
            }
            catch(Exception e)
            {
                System.out.println("Error in opening image");
            }    
        }
    }
   
    //display image
    public void displayImage()
    {
        ImageIcon imageIcon = new ImageIcon(editedImage);
        imageLabel.setIcon(imageIcon);
        frame.pack();
    }
    
    // Save image
 public void saveImage() {
        if (editedImage != null) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showSaveDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) 
            {
                try
                {
                    File selectedFile = fileChooser.getSelectedFile();
                    String filePath = selectedFile.getAbsolutePath();
                    if (!filePath.toLowerCase().endsWith(".jpg")) {
                        selectedFile = new File(filePath + ".jpg"); // Append ".jpg" extension if not present
                    }
                    ImageIO.write(editedImage, "jpg", selectedFile); // Save as JPG format
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    // brightness
   public void brightness(int value) {
    try {
        int width = editedImage.getWidth();
        int height = editedImage.getHeight();
        BufferedImage outImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);


        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                Color color = new Color(editedImage.getRGB(i, j));
                int red = color.getRed() + value;
                int green = color.getGreen() + value;
                int blue = color.getBlue() + value;

                // Clamp values to the valid range (0-255)
                red = Math.min(Math.max(red, 0), 255);
                green = Math.min(Math.max(green, 0), 255);
                blue = Math.min(Math.max(blue, 0), 255);

                Color newColor = new Color(red, green, blue);
                outImg.setRGB(i, j, newColor.getRGB());
            }
        }
        editedImage=outImg;
        displayImage();
    } catch (Exception e) {
        System.out.println("Error in brightness");
    }
}

    
    
    // contrast
    public void contrast(double factor) {
        try {
            int width = editedImage.getWidth();
            int height = editedImage.getHeight();
            BufferedImage outImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    
            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Color color = new Color(editedImage.getRGB(i, j));
                    int red = color.getRed();
                    int green = color.getGreen();
                    int blue = color.getBlue();
    
                    // Adjust contrast using the provided factor
                    red = (int) (factor * (red - 128) + 128);
                    green = (int) (factor * (green - 128) + 128);
                    blue = (int) (factor * (blue - 128) + 128);
    
                    // Clamp values to the valid range (0-255)
                    red = Math.min(Math.max(red, 0), 255);
                    green = Math.min(Math.max(green, 0), 255);
                    blue = Math.min(Math.max(blue, 0), 255);
    
                    Color newColor = new Color(red, green, blue);
                    outImg.setRGB(i, j, newColor.getRGB());
                }
            }
            editedImage = outImg;
            displayImage();
        } catch (Exception e) {
            System.out.println("Error in contrast adjustment");
        }
    }
    
    // inversion
    public void inversion(int ty)
    {
        //if ty == 1 then invert vertically
        //if ty == 2 then invert horizontally
        int width = editedImage.getWidth();
        int height = editedImage.getHeight();
        BufferedImage outImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        if(ty==1)
        {
            try
            {
                for(int i=0; i<width; i++)
                {
                    for(int j=0; j<height; j++)
                    {
                        Color color = new Color(editedImage.getRGB(i, j));
                        int red = color.getRed();
                        int green = color.getGreen();
                        int blue = color.getBlue();
                        Color newColor = new Color(red, green, blue);
                        outImg.setRGB(i, height-j-1, newColor.getRGB());
                    }
                }
                editedImage=outImg;
                displayImage();
            }
            catch(Exception e)
            {
                System.out.println("Error in inversion");
            }
        }
        else if(ty==2)
        {
            try
            {

                for(int i=0; i<width; i++)
                {
                    for(int j=0; j<height; j++)
                    {
                        Color color = new Color(editedImage.getRGB(i, j));
                        int red = color.getRed();
                        int green = color.getGreen();
                        int blue = color.getBlue();
                        Color newColor = new Color(red, green, blue);
                        outImg.setRGB(width-i-1, j, newColor.getRGB());
                    }
                }
                editedImage=outImg;
                displayImage();
            }
            catch(Exception e)
            {
                System.out.println("Error in inversion");
            }
        }
    }
    
    // rotate
  public void rotateImage(int angle) {
    try {
        int width = editedImage.getWidth();
        int height = editedImage.getHeight();
        BufferedImage outImg;

        if (angle == 90 || angle == 270) {
            outImg = new BufferedImage(height, width, BufferedImage.TYPE_INT_RGB);
        } else {
            outImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        }

        for (int j = 0;j < height; j++) {
            for (int i = 0; i < width; i++) {
                int newI, newJ;
                if (angle == 90) {
                    newI = i; // Swap width and height dimensions
                    newJ = height - j - 1;
                }else if (angle == 270) {
                    newI = width - i - 1;
                    newJ = j; // Swap width and height dimensions
                } else { // No rotation
                    newI = i;
                    newJ = j;
                }

                Color color = new Color(editedImage.getRGB(i, j));
                outImg.setRGB(newJ, newI, color.getRGB()); // Swap newI and newJ
            }
        }
        editedImage = outImg;
        displayImage();
    } catch (Exception e) {
        System.out.println("Error in rotating image");
	e.printStackTrace();
    }
}

 public void rotateImage2(int angle) {
    try {
        int width = editedImage.getWidth();
        int height = editedImage.getHeight();
        BufferedImage outImg;

        if (angle == 90 || angle == 270) {
            outImg = new BufferedImage(height, width, BufferedImage.TYPE_INT_RGB);
        } else {
            outImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        }

        for (int i = 0;i < height; i++) {
            for (int j = 0; j < width; j++) {
                int newI, newJ;
                if (angle == 90) {
                    newI = i; // Swap width and height dimensions
                    newJ = height - j - 1;
                }else if (angle == 270) {
                    newI = width - i - 1;
                    newJ = j; // Swap width and height dimensions
                } else { // No rotation
                    newI = height-i-1;
                    newJ = width-j-1;
                }

                Color color = new Color(editedImage.getRGB(j, i));
                outImg.setRGB(newJ, newI, color.getRGB()); // Swap newI and newJ
            }
        }
        editedImage = outImg;
        displayImage();
    } catch (Exception e) {
        System.out.println("Error in rotating image");
	e.printStackTrace();
    }
}



    // effects

    // grayscale
     public void applyGrayscale() {
        try {
            int width = editedImage.getWidth();
            int height = editedImage.getHeight();
            BufferedImage grayscaleImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Color color = new Color(editedImage.getRGB(i, j));
                    int red = color.getRed();
                    int green = color.getGreen();
                    int blue = color.getBlue();
                    int grayscaleValue = (red + green + blue) / 3;

                    Color grayscaleColor = new Color(grayscaleValue, grayscaleValue, grayscaleValue);
                    grayscaleImg.setRGB(i, j, grayscaleColor.getRGB());
                }
            }

            editedImage = grayscaleImg;
            displayImage();
        } catch (Exception e) {
            System.out.println("Error applying grayscale filter");
        }
    }

    // blur

    public void applyBlur(int radius) {
        try {
            int width = editedImage.getWidth();
            int height = editedImage.getHeight();
            BufferedImage blurredImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

            for (int i = radius; i < width - radius; i++) {
                for (int j = radius; j < height - radius; j++) {
                    int sumRed = 0;
                    int sumGreen = 0;
                    int sumBlue = 0;

                    // Apply a variable-sized averaging kernel based on the radius
                    for (int m = -radius; m <= radius; m++) {
                        for (int n = -radius; n <= radius; n++) {
                            Color color = new Color(editedImage.getRGB(i + m, j + n));
                            sumRed += color.getRed();
                            sumGreen += color.getGreen();
                            sumBlue += color.getBlue();
                        }
                    }

                    int averageRed = sumRed / ((2 * radius + 1) * (2 * radius + 1));
                    int averageGreen = sumGreen / ((2 * radius + 1) * (2 * radius + 1));
                    int averageBlue = sumBlue / ((2 * radius + 1) * (2 * radius + 1));

                    Color blurredColor = new Color(averageRed, averageGreen, averageBlue);
                    blurredImg.setRGB(i, j, blurredColor.getRGB());
                }
            }

            editedImage = blurredImg;
            displayImage();
        } catch (Exception e) {
            System.out.println("Error applying blur filter");
        }
    }

    // negative
    public void applyNegativeEffect() {
        try {
            int width = editedImage.getWidth();
            int height = editedImage.getHeight();
            BufferedImage negativeImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Color color = new Color(editedImage.getRGB(i, j));
                    int red = 255 - color.getRed();
                    int green = 255 - color.getGreen();
                    int blue = 255 - color.getBlue();

                    Color negativeColor = new Color(red, green, blue);
                    negativeImg.setRGB(i, j, negativeColor.getRGB());
                }
            }

            editedImage = negativeImg;
            displayImage();
        } catch (Exception e) {
            System.out.println("Error applying negative image effect");
        }
    }
    // fade
    public void applyFade() {
        try {
            int width = editedImage.getWidth();
            int height = editedImage.getHeight();
            BufferedImage fadedImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

            for (int i = 0; i < width; i++) {
                for (int j = 0; j < height; j++) {
                    Color color = new Color(editedImage.getRGB(i, j));
                    int alpha = color.getAlpha();
                    int red = color.getRed();
                    int green = color.getGreen();
                    int blue = color.getBlue();

                    // Reduce opacity by setting the alpha value to 50% (127)
                    Color fadedColor = new Color(red, green, blue, 127);
                    fadedImg.setRGB(i, j, fadedColor.getRGB());
                }
            }

            editedImage = fadedImg;
            displayImage();
        } catch (Exception e) {
            System.out.println("Error applying fade filter");
        }
    }
    // main function
    public static void main(String[] args) 
    {
        new Image_Editor();
        //run img editor
    }    
}
