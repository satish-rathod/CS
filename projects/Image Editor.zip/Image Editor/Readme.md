

# Image Editor

## Table of Contents
- [Introduction](#introduction)
- [Features](#features)
- [Technologies Used](#technologies-used)
- [Getting Started](#getting-started)
- [Usage](#usage)
- [Examples](#examples)

## Introduction
The Image Editor is a Java application that allows users to open, edit, and save images. It provides various image editing functionalities such as brightness adjustment, contrast adjustment, inversion (both vertically and horizontally), rotation, and applying effects like grayscale, negative, blur, and fade.

## Features
- Open and display images in various formats.
- Adjust image brightness.
- Modify image contrast.
- Invert images both vertically and horizontally.
- Rotate images by 90, 180, or 270 degrees.
- Apply various image effects including grayscale, negative, blur, and fade.
- Save edited images.

## Technologies Used
- Java Swing for creating the graphical user interface (GUI).
- Java AWT for handling image operations.
- BufferedImage for image manipulation.

## Getting Started
1. Clone or download the repository to your local machine.
2. Open the project in your preferred Java development environment.
3. Compile and run the `Image_Editor` class.

## Usage
1. Upon running the application, a graphical user interface will appear.
2. Use the **File** menu to open and save images.
3. Use the **Edit** menu to apply various image adjustments and effects.
4. View the edited image in the central display area.
5. Save your edited image using the **Save** option in the **File** menu.

## GUI

*User Interface*

![Interface](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763809/u83vsq1hplaxosmbvihu.png)
![Interface](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763810/cfygpz5pc1ud2vl04bwn.png)
![Interface](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763810/lmjqmk4bdftzkzxffxmz.png)
![Interface](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763810/o1nyrxozbriy9lcnhb4g.png)

## Examples
Here are some examples of the Image Editor in action:

**Original Image:**
![Original Image](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763814/znulzzxaybpchhmjycbs.png)

**Grayscale Effect:**
![Grayscale Effect](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763815/xmdvvohrgdflkrixns67.png)

**Negative Effect:**
![Negative Effect](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763819/kvesuygvjhiagaztxbba.png)

**Blur Effect:**
![Blur Effect](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763819/ybtlodw6pws6gsznvqrl.png)

**Brightness Adjustment:**
![Brightness Adjustment](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763815/jsdrmuyp6uvu17glmeyo.png)

**Contrast Adjustment:**
![Contrast Adjustment](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763817/eoz1fpgpzoqlgevz3oyz.png)

**Invert Vertically:**
![Invert Vertically](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763813/u7nu76guloopleggmxwt.png)

**Invert Horizontally:**
![Invert Horizontally](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763816/j1vvch1baga7h8zwknva.png)

**Rotation (90 degrees):**
![Rotation (90 degrees)](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763819/qfy4q5g04a7yfro12bjc.png)

**Rotation (180 degrees):**
![Rotation (180 degrees)](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763820/i86n5tc8leh3oqemdtpf.png)

**Rotation (270 degrees):**
![Rotation (270 degrees)](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763821/y6akzsxes24pp10kcl3o.png)

**Fade Effect:**
![Fade Effect](https://res.cloudinary.com/dgvnq4qgy/image/upload/v1693763820/rbippbecksal2nhy8jlk.png)
